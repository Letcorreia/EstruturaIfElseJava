package estruturadeControle;

import java.util.Scanner;
public class EstruturaifElseTest {
    public static void main(String args[]) {
    	EstruturaifElse obj= new EstruturaifElse();//criando objeto
    	Double nota;
    	Scanner input= new Scanner(System.in);
    	//pegando dados do usuario
    	System.out.print("Digite a nota:");
    	nota= input.nextDouble();
    	String resultado= obj.avaliacao(nota);
    	String mencao= obj.mencaoAluno(nota);
    	System.out.println("O aluno foi "+ resultado + " com "+ mencao);
    	
    	
    }
}

package estruturadeControle;

public class EstruturaifElse {
	
	public String mencaoAluno(double notaAluno) {
		String aux;
		if(notaAluno > 9) {
			aux = "SS";
		}
		else if (notaAluno > 8 && notaAluno < 9) {
			aux = "MS";
		}
		else if (notaAluno > 7 && notaAluno < 8) {
			aux = "MM";
		}
		else {
			aux= "MN";
		}
		return aux;
		}
	

	
	
	
	
	public String mencaoAluno2(double nota) {
		
		String aux= "";
		switch ((int)nota) {
	    case 9:
			aux="SS";
			break;
	    case 8:
			aux="MS";
			break;
	    case 7:
			aux="MM";
			break;
		default:
			aux="MN";
			break;
		}
	    
		return aux;
	}
	
	public String avaliacao(double nota) {
		
		String mencao;
		if (nota >=7) {
			mencao= "aprovado";
		}
		else {//nota <7
			mencao="reprovado";
		}
		return mencao;
	}

}


